A Pen created at CodePen.io. You can find this one at http://codepen.io/Giovanni1980/pen/VjPzmx.

 A mobile menu template with a sticky header, template for projects, changing the CSS you can make the menu appear from the left or top border.
- works better with svg logos (I use png here).
- you can add some swipe for the mobile user using this nice plugin:
http://joanclaret.github.io/slide-and-swipe-menu/